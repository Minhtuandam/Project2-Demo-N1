/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.cardgame;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author student
 */
public class GameXocDiaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button backButton;

    
    
    @FXML
    private void goBackToPreviousPage(ActionEvent event) {
        try {
//            System.out.println("AN SU KIEN");
            App.setRoot("InGameMenu");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    } 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
