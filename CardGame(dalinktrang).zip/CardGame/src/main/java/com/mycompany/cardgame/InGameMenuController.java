/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.cardgame;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author student
 */
public class InGameMenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private Button btnChoiXocDia;

    @FXML
    private Button btnChoiBaCay;

    @FXML
    private Button btnThoatGame;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Khởi tạo các sự kiện cho các button
        btnChoiXocDia.setOnAction(this::handleChoiXocDia);
        btnChoiBaCay.setOnAction(this::handleChoiBaCay);
        btnThoatGame.setOnAction(this::handleThoatGame);
        
    }    
    
    
    private Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
        return fxmlLoader.load();
    }
   

    private void handleChoiXocDia(ActionEvent event) {
        try {
            App.setRoot("GameXocDia");
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Chọn Chơi xóc đĩa");
    }

    private void handleChoiBaCay(ActionEvent event) {
        try {
            App.setRoot("Game3Card");
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Chọn Chơi 3 cây");
    }

    private void handleThoatGame(ActionEvent event) {
        // Xử lý khi người chơi chọn Thoát game
        // Tắt chương trình
        System.out.println("Chọn Thoát game");
        System.exit(0);
    }

    
}
