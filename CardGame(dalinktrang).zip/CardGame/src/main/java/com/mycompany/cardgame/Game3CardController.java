/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.cardgame;

import java.io.IOException;
import java.net.URL;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author student
 */
public class Game3CardController implements Initializable {

    /**
     * Initializes the controller class.
     */@FXML
    private ImageView card1ImageView;

    @FXML
    private ImageView card2ImageView;

    @FXML
    private ImageView card3ImageView;

    @FXML
    private Button playButton;

    @FXML
    private Button addBotButton;

    @FXML
    private Button bet1Button;

    @FXML
    private Button bet5Button;

    @FXML
    private Button bet10Button;

    @FXML
    private Button bet50Button;

    @FXML
    private Button continueButton;

    @FXML
    private Button quitButton;

    @FXML
    private Label resultLabel;

    @FXML
    private Label moneyLabel;

    private List<String> cards;
    private Random random;

    private int money;
    private int currentBet;

    private boolean isPlaying;
    private boolean isFlipping;

    public void initialize() {
        cards = new ArrayList<>();
        cards.add("2C");
        cards.add("3C");
        cards.add("4C");
        // Add more cards here...

        random = new Random();

        money = 100;
        currentBet = 0;

        updateMoneyLabel();

        setGameUIState(false);
    }

    @FXML
    void playButtonClicked() {
        resetGame();

        int card1Index = random.nextInt(cards.size());
        int card2Index = random.nextInt(cards.size());
        int card3Index = random.nextInt(cards.size());

        String card1 = cards.get(card1Index);
        String card2 = cards.get(card2Index);
        String card3 = cards.get(card3Index);

        Image card1Image = new Image(getClass().getResourceAsStream("/images/back.png"));
        Image card2Image = new Image(getClass().getResourceAsStream("/images/back.png"));
        Image card3Image = new Image(getClass().getResourceAsStream("/images/back.png"));

        card1ImageView.setImage(card1Image);
        card2ImageView.setImage(card2Image);
        card3ImageView.setImage(card3Image);

        playButton.setDisable(true);
        addBotButton.setDisable(false);

        isPlaying = true;
    }

    @FXML
    void addBotButtonClicked() {
        addBotButton.setDisable(true);

        // Add bot logic here...

        startFlippingCards();
    }

    @FXML
    void bet1ButtonClicked() {
        placeBet(1);
    }

    @FXML
    void bet5ButtonClicked() {
        placeBet(5);
    }

    @FXML
    void bet10ButtonClicked() {
        placeBet(10);
    }

    @FXML
    void bet50ButtonClicked() {
        placeBet(50);
    }

    @FXML
    void continueButtonClicked() {
        resetGame();
        setGameUIState(false);
    }

    @FXML
    void quitButtonClicked() {
        // Return to main menu or exit the game
    }

    private void placeBet(int betAmount) {
        if (money >= betAmount) {
            currentBet += betAmount;
            money -= betAmount;

            updateMoneyLabel();

            setGameUIState(true);
        }
    }

    private void resetGame() {
        card1ImageView.setImage(null);
        card2ImageView.setImage(null);
        card3ImageView.setImage(null);

        resultLabel.setText("");
        currentBet = 0;

        playButton.setDisable(false);
        addBotButton.setDisable(true);
    }

    private void updateMoneyLabel() {
        moneyLabel.setText("Money: $" + money);
    }

    private void setGameUIState(boolean isEnabled) {
        bet1Button.setDisable(!isEnabled);
        bet5Button.setDisable(!isEnabled);
        bet10Button.setDisable(!isEnabled);
        bet50Button.setDisable(!isEnabled);
        continueButton.setDisable(!isEnabled);
        quitButton.setDisable(!isEnabled);

        if (!isEnabled) {
            continueButton.setVisible(false);
        } else {
            continueButton.setVisible(true);
        }
    }

    private void startFlippingCards() {
        Timeline timeline;
         timeline = new Timeline(
                 new KeyFrame(Duration.seconds(1), event -> flipCard(card1ImageView, cards.get(0))),
                 new KeyFrame(Duration.seconds(2), event -> flipCard(card2ImageView, cards.get(1))),
                 new KeyFrame(Duration.seconds(3), event -> flipCard(card3ImageView,cards.get(2))),
                 new KeyFrame(Duration.seconds(4), event -> revealCards())
         );
        timeline.play();
    }

    private void flipCard(ImageView cardImageView, String card) {
        Image cardImage = new Image(getClass().getResourceAsStream("/images/" + card + ".png"));
        cardImageView.setImage(cardImage);
    }

    private void revealCards() {
        String card1 = cards.get(0);
        String card2 = cards.get(1);
        String card3 = cards.get(2);

        card1ImageView.setImage(new Image(getClass().getResourceAsStream("/images/" + card1 + ".png")));
        card2ImageView.setImage(new Image(getClass().getResourceAsStream("/images/" + card2 + ".png")));
        card3ImageView.setImage(new Image(getClass().getResourceAsStream("/images/" + card3 + ".png")));

        isFlipping = false;

        evaluateResult(card1, card2, card3);
    }

    private void evaluateResult(String card1, String card2, String card3) {
        // Add result evaluation logic here...

        // Example: If the player wins
        int winnings = currentBet * 2;
        money += winnings;

        updateMoneyLabel();
        resultLabel.setText("You win $" + winnings);

        isPlaying = false;
    }
    @FXML
    private Button backButton;

    
    
    @FXML
    private void goBackToPreviousPage(ActionEvent event) {
        try {
//            System.out.println("AN SU KIEN");
            App.setRoot("InGameMenu");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    } 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
