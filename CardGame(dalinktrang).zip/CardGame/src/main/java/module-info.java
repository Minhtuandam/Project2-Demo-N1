module com.mycompany.cardgame {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.cardgame to javafx.fxml;
    exports com.mycompany.cardgame;
}
